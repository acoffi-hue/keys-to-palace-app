import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Keys to the Palace - Spiritual Manifestation Journey",
  description: "A comprehensive spiritual manifestation app combining the 17 Keys to the Palace with 90-day interactive journaling, guided meditation, and mindfulness exercises.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#9333ea" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Keys to Palace" />
        <script src="https://cdn.tailwindcss.com"></script>
      </head>
      <body>
        <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
          {children}
        </div>
      </body>
    </html>
  );
}