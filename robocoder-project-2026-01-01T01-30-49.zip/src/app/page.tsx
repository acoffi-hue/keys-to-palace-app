"use client";

import { useState } from "react";

export default function Dashboard() {
  const [activeSection, setActiveSection] = useState("dashboard");

  const manifestationKeys = [
    "RBDC: Recognize, Believe, Decide, Commit",
    "Gratitude", 
    "Releasing Control",
    "Crazy Faith & Knowing",
    "Release (Forgiveness)",
    "Find Your Joy",
    "Alignment & Association",
    "Love",
    "Hold the Vision",
    "Persevere",
    "Learn from Mistakes",
    "Celebrate",
    "Have the Conversation (Revisited)",
    "Sacrifice",
    "Perspective", 
    "Define, Refine, Clarify",
    "Take the Step"
  ];

  const todaysAffirmation = "I speak to God openly and honestly. My truth creates space for divine guidance.";

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-purple-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white text-xl">✨</span>
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Keys to the Palace
                </h1>
                <p className="text-sm text-gray-600">Spiritual Manifestation Journey</p>
              </div>
            </div>
            <nav className="hidden md:flex space-x-6">
              <button 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeSection === "dashboard" 
                    ? "text-purple-700 bg-purple-50" 
                    : "text-gray-600 hover:text-gray-900"
                }`}
                onClick={() => setActiveSection("dashboard")}
              >
                Dashboard
              </button>
              <button 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeSection === "keys" 
                    ? "text-purple-700 bg-purple-50" 
                    : "text-gray-600 hover:text-gray-900"
                }`}
                onClick={() => setActiveSection("keys")}
              >
                Keys
              </button>
              <button 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeSection === "journal" 
                    ? "text-purple-700 bg-purple-50" 
                    : "text-gray-600 hover:text-gray-900"
                }`}
                onClick={() => setActiveSection("journal")}
              >
                Journal
              </button>
              <button 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeSection === "meditation" 
                    ? "text-purple-700 bg-purple-50" 
                    : "text-gray-600 hover:text-gray-900"
                }`}
                onClick={() => setActiveSection("meditation")}
              >
                Meditation
              </button>
              <button 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeSection === "affirmations" 
                    ? "text-purple-700 bg-purple-50" 
                    : "text-gray-600 hover:text-gray-900"
                }`}
                onClick={() => setActiveSection("affirmations")}
              >
                Affirmations
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Dashboard Section */}
        {activeSection === "dashboard" && (
          <div>
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Welcome to Your Spiritual Journey</h2>
              <p className="text-xl text-gray-600">Transform your life with the 17 Keys to Manifestation</p>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
              <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-6 rounded-lg shadow-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Current Day</p>
                    <p className="text-3xl font-bold">1</p>
                  </div>
                  <span className="text-4xl">📅</span>
                </div>
              </div>

              <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 rounded-lg shadow-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Keys Mastered</p>
                    <p className="text-3xl font-bold">2/17</p>
                  </div>
                  <span className="text-4xl">🗝️</span>
                </div>
              </div>

              <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-6 rounded-lg shadow-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Journal Streak</p>
                    <p className="text-3xl font-bold">7 days</p>
                  </div>
                  <span className="text-4xl">📖</span>
                </div>
              </div>

              <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white p-6 rounded-lg shadow-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100">Progress</p>
                    <p className="text-3xl font-bold">1%</p>
                  </div>
                  <span className="text-4xl">📈</span>
                </div>
              </div>
            </div>

            {/* Today's Affirmation */}
            <div className="bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 border border-purple-200 rounded-lg p-8 mb-8">
              <h3 className="text-2xl font-bold text-center text-gray-900 mb-4">
                {"Today's Affirmation"}
              </h3>
              <blockquote className="text-xl italic text-center text-gray-700 mb-6">
                {`"${todaysAffirmation}"`}
              </blockquote>
              <div className="text-center">
                <button className="bg-purple-600 hover:bg-purple-700 text-white font-medium py-3 px-8 rounded-lg shadow-lg transition-colors">
                  Listen to Affirmation
                </button>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button 
                  onClick={() => setActiveSection("journal")}
                  className="p-6 border border-gray-200 rounded-lg hover:shadow-md transition-shadow text-center"
                >
                  <span className="text-3xl mb-2 block">📖</span>
                  <span className="font-medium">Journal Entry</span>
                </button>
                <button 
                  onClick={() => setActiveSection("keys")}
                  className="p-6 border border-gray-200 rounded-lg hover:shadow-md transition-shadow text-center"
                >
                  <span className="text-3xl mb-2 block">🗝️</span>
                  <span className="font-medium">Explore Keys</span>
                </button>
                <button 
                  onClick={() => setActiveSection("meditation")}
                  className="p-6 border border-gray-200 rounded-lg hover:shadow-md transition-shadow text-center"
                >
                  <span className="text-3xl mb-2 block">🧘</span>
                  <span className="font-medium">Meditate</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Manifestation Keys Section */}
        {activeSection === "keys" && (
          <div>
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">The 17 Keys to Manifestation</h2>
              <p className="text-lg text-gray-600">Your spiritual and practical framework for transformation</p>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm font-medium">Overall Progress</span>
                <span className="text-sm text-gray-600">2/17 Keys</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-purple-600 h-2 rounded-full" style={{width: '12%'}}></div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {manifestationKeys.map((key, index) => (
                <div 
                  key={index}
                  className={`p-4 rounded-lg border transition-all hover:shadow-md cursor-pointer ${
                    index < 2 ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      index < 2 ? 'bg-purple-600 text-white' : 'bg-gray-300 text-gray-700'
                    }`}>
                      Key {index + 1}
                    </span>
                    {index < 2 && <div className="w-2 h-2 bg-green-500 rounded-full"></div>}
                  </div>
                  <h3 className="font-medium text-sm leading-tight">{key}</h3>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Journal Section */}
        {activeSection === "journal" && (
          <div>
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">90-Day Manifestation Journal</h2>
              <p className="text-lg text-gray-600">Your sacred container for reflection, alignment, and action</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Morning Alignment</h3>
                <p className="text-gray-600 mb-4">Start your day with intention</p>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Gratitude</label>
                    <textarea 
                      className="w-full p-3 border border-gray-200 rounded-lg resize-none"
                      rows={3}
                      placeholder="What are you grateful for today?"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Intention for Today</label>
                    <textarea 
                      className="w-full p-3 border border-gray-200 rounded-lg resize-none"
                      rows={3}
                      placeholder="What is your intention for today?"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Aligned Action</label>
                    <textarea 
                      className="w-full p-3 border border-gray-200 rounded-lg resize-none"
                      rows={3}
                      placeholder="What aligned action will you take?"
                    />
                  </div>
                  <button className="w-full bg-yellow-600 hover:bg-yellow-700 text-white font-medium py-3 rounded-lg">
                    Save Morning Entry
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Evening Reflection</h3>
                <p className="text-gray-600 mb-4">{"Reflect on your day's journey"}</p>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Evening Reflection</label>
                  <textarea 
                    className="w-full p-3 border border-gray-200 rounded-lg resize-none"
                    rows={8}
                    placeholder="How did today unfold? What did you learn? What are you releasing?"
                  />
                </div>
                <button className="w-full mt-4 bg-purple-600 hover:bg-purple-700 text-white font-medium py-3 rounded-lg">
                  Save Evening Entry
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Meditation Section */}
        {activeSection === "meditation" && (
          <div>
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Meditation Center</h2>
              <p className="text-lg text-gray-600">Guided meditation and mindfulness for enhanced focus and spiritual growth</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6">
                <h3 className="text-xl font-bold text-blue-800 mb-2">Breath Awareness</h3>
                <p className="text-blue-700 mb-4">Foundation practice for presence</p>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Duration</span>
                    <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">5-10 min</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Level</span>
                    <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">Beginner</span>
                  </div>
                </div>
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 rounded-lg">
                  Start Session
                </button>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-6">
                <h3 className="text-xl font-bold text-purple-800 mb-2">Manifestation Visualization</h3>
                <p className="text-purple-700 mb-4">Align with your highest vision</p>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Duration</span>
                    <span className="text-sm bg-purple-100 text-purple-800 px-2 py-1 rounded">15-20 min</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Level</span>
                    <span className="text-sm bg-purple-100 text-purple-800 px-2 py-1 rounded">Intermediate</span>
                  </div>
                </div>
                <button className="w-full bg-purple-600 hover:bg-purple-700 text-white font-medium py-3 rounded-lg">
                  Start Session
                </button>
              </div>

              <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-lg p-6">
                <h3 className="text-xl font-bold text-green-800 mb-2">Focus Training</h3>
                <p className="text-green-700 mb-4">Enhance concentration and clarity</p>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Duration</span>
                    <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded">10-15 min</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Level</span>
                    <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded">All Levels</span>
                  </div>
                </div>
                <button className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-3 rounded-lg">
                  Start Session
                </button>
              </div>
            </div>

            {/* Mindful Moments */}
            <div className="bg-white rounded-lg shadow-lg p-6 mt-8">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Mindful Moments</h3>
              <p className="text-gray-600 mb-6">Quick practices for busy schedules</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium mb-2">Box Breathing</h4>
                  <p className="text-sm text-gray-600 mb-3">4-4-4-4 pattern for instant calm</p>
                  <button className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded text-sm">
                    Start (2 min)
                  </button>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium mb-2">Gratitude Pause</h4>
                  <p className="text-sm text-gray-600 mb-3">Shift to appreciation</p>
                  <button className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded text-sm">
                    Start (1 min)
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Manifestation Keys Section */}
        {activeSection === "keys" && (
          <div>
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">The 17 Keys to Manifestation</h2>
              <p className="text-lg text-gray-600">Your spiritual and practical framework for transformation</p>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm font-medium">Overall Progress</span>
                <span className="text-sm text-gray-600">2/17 Keys</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-purple-600 h-2 rounded-full" style={{width: '12%'}}></div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {manifestationKeys.map((key, index) => (
                <div 
                  key={index}
                  className={`p-4 rounded-lg border transition-all hover:shadow-md cursor-pointer ${
                    index < 2 ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      index < 2 ? 'bg-purple-600 text-white' : 'bg-gray-300 text-gray-700'
                    }`}>
                      Key {index + 1}
                    </span>
                    {index < 2 && <div className="w-2 h-2 bg-green-500 rounded-full"></div>}
                  </div>
                  <h3 className="font-medium text-sm leading-tight">{key}</h3>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Journal Section */}
        {activeSection === "journal" && (
          <div>
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">90-Day Manifestation Journal</h2>
              <p className="text-lg text-gray-600">Your sacred container for reflection, alignment, and action</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Morning Alignment</h3>
                <p className="text-gray-600 mb-4">Start your day with intention</p>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Gratitude</label>
                    <textarea 
                      className="w-full p-3 border border-gray-200 rounded-lg resize-none"
                      rows={3}
                      placeholder="What are you grateful for today?"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Intention for Today</label>
                    <textarea 
                      className="w-full p-3 border border-gray-200 rounded-lg resize-none"
                      rows={3}
                      placeholder="What is your intention for today?"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Aligned Action</label>
                    <textarea 
                      className="w-full p-3 border border-gray-200 rounded-lg resize-none"
                      rows={3}
                      placeholder="What aligned action will you take?"
                    />
                  </div>
                  <button className="w-full bg-yellow-600 hover:bg-yellow-700 text-white font-medium py-3 rounded-lg">
                    Save Morning Entry
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Evening Reflection</h3>
                <p className="text-gray-600 mb-4">{"Reflect on your day's journey"}</p>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Evening Reflection</label>
                  <textarea 
                    className="w-full p-3 border border-gray-200 rounded-lg resize-none"
                    rows={8}
                    placeholder="How did today unfold? What did you learn? What are you releasing?"
                  />
                </div>
                <button className="w-full mt-4 bg-purple-600 hover:bg-purple-700 text-white font-medium py-3 rounded-lg">
                  Save Evening Entry
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Affirmations Section */}
        {activeSection === "affirmations" && (
          <div>
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Affirmation Hub</h2>
              <p className="text-lg text-gray-600">Daily affirmations for spiritual alignment and manifestation</p>
            </div>

            <div className="bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 border border-purple-200 rounded-lg p-8 mb-8">
              <h3 className="text-2xl font-bold text-center text-gray-900 mb-4">
                {"Today's Affirmation"}
              </h3>
              <blockquote className="text-xl italic text-center text-gray-700 mb-6">
                {`"${todaysAffirmation}"`}
              </blockquote>
              <div className="text-center space-x-4">
                <button className="bg-purple-600 hover:bg-purple-700 text-white font-medium py-3 px-6 rounded-lg">
                  Listen
                </button>
                <button className="border border-purple-600 text-purple-600 hover:bg-purple-50 font-medium py-3 px-6 rounded-lg">
                  Favorite
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                "I recognize my power, believe in my becoming, decide with clarity, and commit with devotion.",
                "I honor what I have, and gratitude multiplies the good in my life.",
                "I release what I cannot control and trust divine timing to support me.",
                "I trust my knowing. My faith shapes my reality in perfect timing.",
                "I forgive to free myself. My heart is light, open, and restored.",
                "I allow joy to guide me. My light attracts aligned experiences."
              ].map((affirmation, index) => (
                <div key={index} className="bg-white rounded-lg shadow p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="mb-3">
                    <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded">
                      Spiritual Alignment
                    </span>
                  </div>
                  <blockquote className="text-sm font-medium text-gray-900 leading-relaxed mb-3">
                    {`"${affirmation}"`}
                  </blockquote>
                  <button className="w-full border border-gray-200 hover:bg-gray-50 py-2 rounded text-sm">
                    Practice
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="bg-white/80 backdrop-blur-sm border-t border-purple-100 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <p className="text-gray-600 mb-2">
              {`"Manifestation is not merely the pursuit of material things. It is the process of becoming the version of yourself capable of holding peace, purpose, power, and prosperity."`}
            </p>
            <p className="text-sm text-gray-500">— Ayesha Coffi, Keys to the Palace</p>
          </div>
        </div>
      </footer>
    </div>
  );
}