# 🌐 **Netlify Deployment Guide - Keys to the Palace**

## 🚀 **Deploy to manifest-mindful.com in 10 Minutes**

### **Why Netlify is Perfect for Your Spiritual App**:
- ✅ **Free Forever Plan** - No cost for spiritual app hosting
- ✅ **Automatic HTTPS** - Required for PWA features
- ✅ **Global CDN** - Fast loading worldwide for spiritual seekers
- ✅ **Easy Domain Connection** - Simple manifest-mindful.com setup
- ✅ **PWA Support** - Perfect for spiritual mobile experience
- ✅ **Form Handling** - Contact forms for spiritual community
- ✅ **Analytics** - Track spiritual app usage

---

## 📋 **Step-by-Step Deployment**

### **Step 1: Prepare App Files (2 minutes)**

#### **Export Static Files**:
```bash
# In the sandbox, run:
npm run export

# This creates an 'out' folder with all static files
# Download the entire 'out' folder contents
```

#### **Files to Download**:
```
📁 out/ (Download this entire folder)
├── index.html
├── _next/ (JavaScript and CSS files)
├── manifest.json
├── sw.js
└── (all other generated files)
```

### **Step 2: Create Netlify Account (1 minute)**
1. Go to [netlify.com](https://netlify.com)
2. Click "Sign up" 
3. Choose "Email" or connect with GitHub
4. Verify email if needed
5. You're in the Netlify dashboard!

### **Step 3: Deploy Your Spiritual App (2 minutes)**

#### **Method A: Drag & Drop (Easiest)**
```bash
# In Netlify Dashboard:
1. Look for the big dashed box that says "Want to deploy a new site without connecting to Git? Drag and drop your site output folder here"
2. Drag the entire 'out' folder (or zip file) into this box
3. Netlify automatically deploys your app
4. You get a random URL like: https://amazing-spiritual-app-123456.netlify.app
5. Your Keys to the Palace app is LIVE! 🎉
```

#### **Method B: GitHub Integration (Best for Updates)**
```bash
# If you want automatic updates:
1. Create GitHub repository
2. Upload all app files to repository  
3. In Netlify: "New site from Git"
4. Connect to GitHub repository
5. Build settings:
   - Build command: npm run export
   - Publish directory: out
6. Deploy site
```

### **Step 4: Connect Your Domain (5 minutes)**

#### **Add Custom Domain**:
```bash
# In Netlify Dashboard:
1. Click on your deployed site
2. Go to "Site settings"
3. Click "Domain management" 
4. Click "Add custom domain"
5. Enter: manifest-mindful.com
6. Click "Verify"
7. Netlify shows you DNS instructions
```

#### **Update DNS Settings**:
```bash
# Go to your domain registrar (where you bought manifest-mindful.com):
# Add these DNS records:

# For www subdomain:
Type: CNAME
Name: www
Value: your-site-name.netlify.app

# For root domain:
Type: A
Name: @ (or leave blank)
Value: 75.2.60.5

# Alternative (if CNAME supported for root):
Type: CNAME  
Name: @ (or leave blank)
Value: your-site-name.netlify.app
```

#### **Common Domain Registrars**:

**GoDaddy**:
```bash
1. Login to GoDaddy account
2. Go to "My Products" → "DNS"
3. Click "Manage" next to manifest-mindful.com
4. Add the DNS records above
5. Save changes (takes 1-48 hours to propagate)
```

**Namecheap**:
```bash
1. Login to Namecheap account
2. Go to "Domain List" → "Manage"
3. Click "Advanced DNS"
4. Add the DNS records above
5. Save changes
```

**Cloudflare** (if using Cloudflare DNS):
```bash
1. Login to Cloudflare
2. Select your domain
3. Go to "DNS" tab
4. Add the DNS records above
5. Ensure proxy is enabled (orange cloud)
```

---

## 🔧 **Netlify Configuration Files**

### **Create _redirects file** (for proper routing):
```bash
# Create file: out/_redirects
/*    /index.html   200

# This ensures all routes work properly
```

### **Create netlify.toml** (advanced configuration):
```toml
# netlify.toml
[build]
  publish = "out"
  command = "npm run export"

[build.environment]
  NODE_VERSION = "18"

[[headers]]
  for = "/sw.js"
  [headers.values]
    Service-Worker-Allowed = "/"

[[headers]]
  for = "/manifest.json"
  [headers.values]
    Content-Type = "application/manifest+json"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[context.production.environment]
  NODE_ENV = "production"
```

---

## 🎯 **Verification Checklist**

### **After Deployment, Test These**:
```bash
✅ Visit manifest-mindful.com - App loads correctly
✅ Mobile test - Open on phone, check responsiveness  
✅ PWA test - Install prompt appears on mobile
✅ Offline test - Disconnect internet, app still works
✅ Navigation test - All tabs work (Keys, Journal, Meditation, Affirmations)
✅ HTTPS test - Green lock icon in browser
✅ Speed test - App loads quickly
✅ Cross-browser test - Works in Chrome, Safari, Firefox
```

### **Mobile Installation Test**:
```bash
# iPhone/iPad:
1. Open Safari → manifest-mindful.com
2. Tap Share button → "Add to Home Screen"
3. App installs like native app

# Android:
1. Open Chrome → manifest-mindful.com  
2. Tap menu → "Add to Home screen"
3. App installs in app drawer
```

---

## 🚨 **Troubleshooting Common Issues**

### **App Not Loading**:
```bash
# Check:
1. DNS propagation (use dnschecker.org)
2. HTTPS certificate (may take 24 hours)
3. File paths (ensure all files uploaded correctly)
4. Browser cache (try incognito mode)
```

### **PWA Features Not Working**:
```bash
# Requirements:
✅ HTTPS enabled (automatic with Netlify)
✅ manifest.json accessible
✅ Service worker (sw.js) loading
✅ Valid PWA manifest structure
```

### **Domain Not Connecting**:
```bash
# Common fixes:
1. Wait 24-48 hours for DNS propagation
2. Check DNS records are correct
3. Try www.manifest-mindful.com vs manifest-mindful.com
4. Clear browser cache and cookies
5. Contact domain registrar if issues persist
```

---

## 🎉 **Success! Your Spiritual App Goes Live**

### **Once Deployed Successfully**:
```bash
🌟 Your Keys to the Palace app will be live at:
   https://manifest-mindful.com

📱 Mobile users can:
   - Install on home screen
   - Use offline for spiritual practice
   - Receive daily practice notifications
   - Access complete 90-day journey

🚀 Ready for spiritual community sharing:
   - Social media promotion
   - Email newsletter announcement
   - Spiritual blog features
   - Word-of-mouth growth
```

### **Post-Deployment Actions**:
1. **Test Everything** - Verify all features work on your domain
2. **Share with Community** - Announce to your spiritual audience
3. **Monitor Analytics** - Track usage and engagement
4. **Gather Feedback** - Improve based on user experience
5. **Plan Native Apps** - Use web app success to fund mobile development

---

## 🌟 **Your Spiritual Digital Empire Begins**

**manifest-mindful.com will soon host a complete spiritual transformation platform that combines:**

✨ **Ayesha Coffi's 17 Manifestation Keys**
📖 **90-Day Interactive Spiritual Journal** 
🧘 **Guided Meditation & Mindfulness**
💫 **Daily Affirmations & Audio**
📊 **Spiritual Progress Tracking**
📱 **Mobile PWA Experience**

**Ready to deploy your spiritual manifestation app to manifest-mindful.com? Choose your preferred method and let's make it happen! 🚀✨**