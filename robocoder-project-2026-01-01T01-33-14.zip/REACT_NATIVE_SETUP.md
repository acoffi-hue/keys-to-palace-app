# 📱 React Native Conversion - Keys to the Palace

## 🚀 **Project Setup Commands**

### **1. Initialize React Native Project**
```bash
# Create new React Native project with TypeScript
npx react-native@latest init KeysToPalaceMobile --template react-native-template-typescript

# Navigate to project directory
cd KeysToPalaceMobile

# Install additional dependencies
npm install @react-navigation/native @react-navigation/stack @react-navigation/bottom-tabs
npm install react-native-screens react-native-safe-area-context
npm install @react-native-async-storage/async-storage
npm install react-native-sqlite-storage
npm install @react-native-community/push-notification-ios
npm install react-native-push-notification
npm install react-native-biometrics
npm install react-native-sound
npm install react-native-share
npm install react-native-haptic-feedback
npm install react-native-vector-icons
npm install react-native-linear-gradient
npm install @reduxjs/toolkit react-redux
npm install react-query
npm install date-fns
npm install react-native-paper

# iOS specific setup
cd ios && pod install && cd ..
```

### **2. Project Structure**
```
KeysToPalaceMobile/
├── src/
│   ├── components/
│   │   ├── common/
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Input.tsx
│   │   │   └── LoadingSpinner.tsx
│   │   ├── keys/
│   │   │   ├── KeyCard.tsx
│   │   │   ├── KeyDetail.tsx
│   │   │   └── KeyProgress.tsx
│   │   ├── journal/
│   │   │   ├── JournalEntry.tsx
│   │   │   ├── MorningAlignment.tsx
│   │   │   └── EveningReflection.tsx
│   │   ├── meditation/
│   │   │   ├── MeditationTimer.tsx
│   │   │   ├── SessionCard.tsx
│   │   │   └── AudioPlayer.tsx
│   │   └── affirmations/
│   │       ├── AffirmationCard.tsx
│   │       ├── DailyAffirmation.tsx
│   │       └── AffirmationPlayer.tsx
│   ├── screens/
│   │   ├── auth/
│   │   │   ├── LoginScreen.tsx
│   │   │   ├── RegisterScreen.tsx
│   │   │   └── BiometricSetupScreen.tsx
│   │   ├── main/
│   │   │   ├── DashboardScreen.tsx
│   │   │   ├── KeysScreen.tsx
│   │   │   ├── JournalScreen.tsx
│   │   │   ├── MeditationScreen.tsx
│   │   │   └── AffirmationsScreen.tsx
│   │   └── settings/
│   │       ├── SettingsScreen.tsx
│   │       ├── NotificationSettings.tsx
│   │       └── ProfileScreen.tsx
│   ├── navigation/
│   │   ├── AppNavigator.tsx
│   │   ├── AuthNavigator.tsx
│   │   ├── MainTabNavigator.tsx
│   │   └── types.ts
│   ├── services/
│   │   ├── api/
│   │   │   ├── auth.ts
│   │   │   ├── journal.ts
│   │   │   ├── progress.ts
│   │   │   └── sync.ts
│   │   ├── storage/
│   │   │   ├── database.ts
│   │   │   ├── asyncStorage.ts
│   │   │   └── migrations.ts
│   │   ├── notifications/
│   │   │   ├── pushNotifications.ts
│   │   │   ├── localNotifications.ts
│   │   │   └── scheduler.ts
│   │   └── audio/
│   │       ├── audioManager.ts
│   │       ├── meditationAudio.ts
│   │       └── textToSpeech.ts
│   ├── store/
│   │   ├── slices/
│   │   │   ├── authSlice.ts
│   │   │   ├── journalSlice.ts
│   │   │   ├── progressSlice.ts
│   │   │   └── settingsSlice.ts
│   │   ├── store.ts
│   │   └── types.ts
│   ├── utils/
│   │   ├── constants.ts
│   │   ├── helpers.ts
│   │   ├── dateUtils.ts
│   │   ├── validation.ts
│   │   └── biometrics.ts
│   ├── assets/
│   │   ├── images/
│   │   ├── sounds/
│   │   ├── fonts/
│   │   └── data/
│   └── types/
│       ├── navigation.ts
│       ├── journal.ts
│       ├── keys.ts
│       └── user.ts
├── android/
├── ios/
└── package.json
```

## 📱 **Core Component Examples**

### **1. Main App Navigator**
```typescript
// src/navigation/AppNavigator.tsx
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { useSelector } from 'react-redux';
import AuthNavigator from './AuthNavigator';
import MainTabNavigator from './MainTabNavigator';
import { RootState } from '../store/store';

const Stack = createStackNavigator();

const AppNavigator: React.FC = () => {
  const isAuthenticated = useSelector((state: RootState) => state.auth.isAuthenticated);

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {isAuthenticated ? (
          <Stack.Screen name="Main" component={MainTabNavigator} />
        ) : (
          <Stack.Screen name="Auth" component={AuthNavigator} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;
```

### **2. Dashboard Screen**
```typescript
// src/screens/main/DashboardScreen.tsx
import React, { useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import LinearGradient from 'react-native-linear-gradient';
import { Card, Button } from '../../components/common';
import { DailyAffirmation } from '../../components/affirmations';
import { ProgressCard } from '../../components/progress';
import { RootState } from '../../store/store';
import { loadDashboardData } from '../../store/slices/dashboardSlice';

const { width } = Dimensions.get('window');

const DashboardScreen: React.FC = () => {
  const dispatch = useDispatch();
  const { currentDay, journalStreak, completedKeys, todaysAffirmation } = useSelector(
    (state: RootState) => state.dashboard
  );

  useEffect(() => {
    dispatch(loadDashboardData());
  }, [dispatch]);

  return (
    <LinearGradient
      colors={['#f3e8ff', '#ffffff', '#dbeafe']}
      style={styles.container}
    >
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Welcome to Your Spiritual Journey</Text>
          <Text style={styles.subtitle}>Day {currentDay} of your 90-day manifestation portal</Text>
        </View>

        {/* Stats Cards */}
        <View style={styles.statsContainer}>
          <View style={styles.statsRow}>
            <Card style={[styles.statCard, { backgroundColor: '#8b5cf6' }]}>
              <Text style={styles.statLabel}>Current Day</Text>
              <Text style={styles.statValue}>{currentDay}</Text>
            </Card>
            <Card style={[styles.statCard, { backgroundColor: '#3b82f6' }]}>
              <Text style={styles.statLabel}>Keys Mastered</Text>
              <Text style={styles.statValue}>{completedKeys}/17</Text>
            </Card>
          </View>
          <View style={styles.statsRow}>
            <Card style={[styles.statCard, { backgroundColor: '#10b981' }]}>
              <Text style={styles.statLabel}>Journal Streak</Text>
              <Text style={styles.statValue}>{journalStreak} days</Text>
            </Card>
            <Card style={[styles.statCard, { backgroundColor: '#f59e0b' }]}>
              <Text style={styles.statLabel}>Progress</Text>
              <Text style={styles.statValue}>{Math.round((currentDay / 90) * 100)}%</Text>
            </Card>
          </View>
        </View>

        {/* Daily Affirmation */}
        <DailyAffirmation affirmation={todaysAffirmation} />

        {/* Quick Actions */}
        <Card style={styles.quickActions}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionButtons}>
            <Button
              title="Journal Entry"
              onPress={() => {/* Navigate to journal */}}
              style={styles.actionButton}
            />
            <Button
              title="Explore Keys"
              onPress={() => {/* Navigate to keys */}}
              style={styles.actionButton}
            />
            <Button
              title="Meditate"
              onPress={() => {/* Navigate to meditation */}}
              style={styles.actionButton}
            />
          </View>
        </Card>
      </ScrollView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 20,
    paddingTop: 60,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
  },
  statsContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  statCard: {
    width: (width - 52) / 2,
    padding: 20,
    alignItems: 'center',
  },
  statLabel: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 14,
    marginBottom: 8,
  },
  statValue: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  quickActions: {
    margin: 20,
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 16,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    flex: 1,
    marginHorizontal: 4,
  },
});

export default DashboardScreen;
```

### **3. Manifestation Key Component**
```typescript
// src/components/keys/KeyCard.tsx
import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { ManifestationKey } from '../../types/keys';

interface KeyCardProps {
  keyData: ManifestationKey;
  onPress: () => void;
}

const KeyCard: React.FC<KeyCardProps> = ({ keyData, onPress }) => {
  return (
    <TouchableOpacity
      style={[
        styles.container,
        keyData.completed && styles.completedContainer
      ]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.header}>
        <View style={[styles.badge, keyData.completed && styles.completedBadge]}>
          <Text style={[styles.badgeText, keyData.completed && styles.completedBadgeText]}>
            Key {keyData.id}
          </Text>
        </View>
        {keyData.completed && <View style={styles.completedIndicator} />}
      </View>
      <Text style={styles.title}>{keyData.title}</Text>
      <Text style={styles.description}>{keyData.description}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f9fafb',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  completedContainer: {
    backgroundColor: '#f0fdf4',
    borderColor: '#bbf7d0',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  badge: {
    backgroundColor: '#e5e7eb',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  completedBadge: {
    backgroundColor: '#8b5cf6',
  },
  badgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6b7280',
  },
  completedBadgeText: {
    color: 'white',
  },
  completedIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10b981',
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 8,
    lineHeight: 20,
  },
  description: {
    fontSize: 14,
    color: '#6b7280',
    lineHeight: 18,
  },
});

export default KeyCard;
```

### **4. Journal Entry Component**
```typescript
// src/components/journal/JournalEntry.tsx
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { Card, Button } from '../common';
import { JournalEntryData } from '../../types/journal';

interface JournalEntryProps {
  initialData?: JournalEntryData;
  onSave: (data: JournalEntryData) => void;
  type: 'morning' | 'evening';
}

const JournalEntry: React.FC<JournalEntryProps> = ({
  initialData,
  onSave,
  type
}) => {
  const [gratitude, setGratitude] = useState(initialData?.gratitude || '');
  const [intention, setIntention] = useState(initialData?.intention || '');
  const [alignedAction, setAlignedAction] = useState(initialData?.alignedAction || '');
  const [reflection, setReflection] = useState(initialData?.reflection || '');

  const handleSave = () => {
    const data: JournalEntryData = {
      gratitude,
      intention,
      alignedAction,
      reflection,
      date: new Date().toISOString(),
      type,
    };
    onSave(data);
  };

  return (
    <ScrollView style={styles.container}>
      <Card style={styles.card}>
        <Text style={styles.title}>
          {type === 'morning' ? 'Morning Alignment' : 'Evening Reflection'}
        </Text>
        <Text style={styles.subtitle}>
          {type === 'morning' 
            ? 'Start your day with intention' 
            : 'Reflect on your spiritual journey'
          }
        </Text>

        {type === 'morning' && (
          <>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Gratitude</Text>
              <TextInput
                style={styles.textInput}
                multiline
                numberOfLines={3}
                placeholder="What are you grateful for today?"
                value={gratitude}
                onChangeText={setGratitude}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Intention for Today</Text>
              <TextInput
                style={styles.textInput}
                multiline
                numberOfLines={3}
                placeholder="What is your intention for today?"
                value={intention}
                onChangeText={setIntention}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Aligned Action</Text>
              <TextInput
                style={styles.textInput}
                multiline
                numberOfLines={3}
                placeholder="What aligned action will you take?"
                value={alignedAction}
                onChangeText={setAlignedAction}
              />
            </View>
          </>
        )}

        {type === 'evening' && (
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Evening Reflection</Text>
            <TextInput
              style={[styles.textInput, styles.largeTextInput]}
              multiline
              numberOfLines={6}
              placeholder="How did today unfold? What did you learn? What are you releasing?"
              value={reflection}
              onChangeText={setReflection}
            />
          </View>
        )}

        <Button
          title={`Save ${type === 'morning' ? 'Morning' : 'Evening'} Entry`}
          onPress={handleSave}
          style={styles.saveButton}
        />
      </Card>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  card: {
    margin: 20,
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
    marginBottom: 24,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#d1d5db',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: 'white',
    textAlignVertical: 'top',
  },
  largeTextInput: {
    minHeight: 120,
  },
  saveButton: {
    marginTop: 20,
  },
});

export default JournalEntry;
```

## 🔧 **Native Module Integration**

### **1. Biometric Authentication**
```typescript
// src/utils/biometrics.ts
import TouchID from 'react-native-biometrics';

export const isBiometricAvailable = async (): Promise<boolean> => {
  try {
    const { available } = await TouchID.isSensorAvailable();
    return available;
  } catch (error) {
    return false;
  }
};

export const authenticateWithBiometrics = async (): Promise<boolean> => {
  try {
    const { success } = await TouchID.simplePrompt({
      promptMessage: 'Authenticate to access your spiritual journal',
      fallbackPromptMessage: 'Use passcode',
    });
    return success;
  } catch (error) {
    return false;
  }
};
```

### **2. Push Notifications**
```typescript
// src/services/notifications/pushNotifications.ts
import PushNotification from 'react-native-push-notification';
import { Platform } from 'react-native';

export const initializePushNotifications = () => {
  PushNotification.configure({
    onRegister: (token) => {
      console.log('Push notification token:', token);
    },
    onNotification: (notification) => {
      console.log('Notification received:', notification);
    },
    permissions: {
      alert: true,
      badge: true,
      sound: true,
    },
    popInitialNotification: true,
    requestPermissions: Platform.OS === 'ios',
  });
};

export const scheduleDailyReminder = (hour: number, minute: number, message: string) => {
  PushNotification.localNotificationSchedule({
    message,
    date: new Date(Date.now() + 60 * 1000), // Test notification
    repeatType: 'day',
    actions: ['Open Journal', 'Meditate'],
  });
};
```

### **3. Audio Integration**
```typescript
// src/services/audio/audioManager.ts
import Sound from 'react-native-sound';

export class AudioManager {
  private currentSound: Sound | null = null;

  playMeditationAudio = (filename: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      this.currentSound = new Sound(filename, Sound.MAIN_BUNDLE, (error) => {
        if (error) {
          reject(error);
          return;
        }
        
        this.currentSound?.play((success) => {
          if (success) {
            resolve();
          } else {
            reject(new Error('Audio playback failed'));
          }
        });
      });
    });
  };

  pauseAudio = () => {
    this.currentSound?.pause();
  };

  stopAudio = () => {
    this.currentSound?.stop();
    this.currentSound?.release();
    this.currentSound = null;
  };
}

export const audioManager = new AudioManager();
```

## 📱 **Platform-Specific Features**

### **iOS Integration**
```swift
// ios/KeysToPalaceMobile/AppDelegate.m
#import <UserNotifications/UserNotifications.h>
#import <RNCPushNotificationIOS.h>

// Add to didFinishLaunchingWithOptions
UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
center.delegate = self;
```

### **Android Integration**
```xml
<!-- android/app/src/main/AndroidManifest.xml -->
<uses-permission android:name="android.permission.VIBRATE" />
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
<uses-permission android:name="android.permission.USE_BIOMETRIC" />
<uses-permission android:name="android.permission.USE_FINGERPRINT" />
```

## 🚀 **Build & Deployment**

### **iOS Build**
```bash
# Debug build
npx react-native run-ios

# Release build
cd ios
xcodebuild -workspace KeysToPalaceMobile.xcworkspace -scheme KeysToPalaceMobile -configuration Release -destination generic/platform=iOS -archivePath KeysToPalaceMobile.xcarchive archive
```

### **Android Build**
```bash
# Debug build
npx react-native run-android

# Release build
cd android
./gradlew assembleRelease
```

This React Native setup provides a solid foundation for converting the Keys to the Palace web app into native mobile applications with enhanced spiritual features and mobile-optimized user experience.